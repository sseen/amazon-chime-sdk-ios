//
//  cwt.h
//  cwt
//
//  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
//

#ifndef CWT_H
#define CWT_H

// Umbrella header for the CWT framework.
#include "CwtEnum.h"
#include "CwtTfLiteModel.h"

#endif  // CWT_H
